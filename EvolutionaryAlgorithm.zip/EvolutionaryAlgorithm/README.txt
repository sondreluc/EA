To run the project, simply run EvolutionaryAlgorithm.exe
