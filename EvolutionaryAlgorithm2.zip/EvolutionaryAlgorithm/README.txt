To run the project, simply run EvolutionaryAlgorithm.exe
Training data for Izhikevich Spike Trains must be placed in the Training Data folder.
